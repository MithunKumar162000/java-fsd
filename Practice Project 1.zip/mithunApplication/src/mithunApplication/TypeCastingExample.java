package mithunApplication;

public class TypeCastingExample {


		public static void main(String[] args) {
			int intValue = 10;
	        double doubleValue = intValue; // Implicitly cast int to double
	        System.out.println("Implicit Typecasting (Widening):");
	        System.out.println("int value: " + intValue);
	        System.out.println("double value: " + doubleValue);

	        
	        double anotherDoubleValue = 15.75;
	        int anotherIntValue = (int) anotherDoubleValue; // Explicitly cast double to int
	        System.out.println("\nExplicit Typecasting (Narrowing):");
	        System.out.println("double value: " + anotherDoubleValue);
	        System.out.println("int value: " + anotherIntValue);
		}

	}
