package mithunPractice;

public class implementingandwaysofmethods {
		 public void greet() {
		        System.out.println("Hello!");
		    }

		    public int add(int a, int b) {
		        return a + b;
		    }

		    public void printMessage(String message) {
		        System.out.println("Message: " + message);
		    }

		    public static void main(String[] args) {
		    	implementingandwaysofmethods demo = new implementingandwaysofmethods();

		        demo.greet();

		        int sum = demo.add(5, 3);
		        System.out.println("Sum: " + sum);

		        demo.printMessage("This is a custom message");
		    }
		}