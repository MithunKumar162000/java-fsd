package mithunPractice;

public class constructorTypes {
	public constructorTypes() {
        System.out.println("Default constructor called.");
    }

    public constructorTypes(String message) {
        System.out.println("Parameterized constructor called with message: " + message);
    }

    public constructorTypes(int number) {
        System.out.println("Parameterized constructor called with number: " + number);
    }

    public static void main(String[] args) {
        constructorTypes defaultConstructor = new constructorTypes();
        constructorTypes parameterizedConstructor = new constructorTypes("Hello, Constructor!");
        constructorTypes overloadedConstructor = new constructorTypes(42);
    }
}

