package mithunPractice;


public class implementationsofcollections {
    public static void main(String[] args) {
        // Create an array of integers
        int[] numbers = { 5, 10, 15, 20, 25 };

        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        System.out.println("Sum of elements: " + sum);

        double average = (double) sum / numbers.length;
        System.out.println("Average of elements: " + average);

        int max = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        System.out.println("Maximum element: " + max);
    }
}
