package mithunPractice;

public class innerclassverification {

	    private int outerVar = 10;

	    public void outerMethod() {
	        System.out.println("Outer Method");
	    }

	    static class StaticInnerClass {
	        public void display() {
	            System.out.println("Static Inner Class");
	        }
	    }
	    class NonStaticInnerClass {
	        public void display() {
	            System.out.println("Non-Static Inner Class");
	     
	            System.out.println("Outer Variable from Inner Class: " + outerVar);
	            outerMethod();
	        }
	    }

	    public static void main(String[] args) {
	     
	    	innerclassverification outerObj = new innerclassverification();

	        StaticInnerClass staticInner = new StaticInnerClass();
	        staticInner.display();
	        
	        NonStaticInnerClass nonStaticInner = outerObj.new NonStaticInnerClass();
	        nonStaticInner.display();
	    }
	}