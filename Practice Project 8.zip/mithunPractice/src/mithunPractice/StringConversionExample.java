package mithunPractice;

public class StringConversionExample {

	    public static void main(String[] args) {
	        // Create a String
	        String originalString = "Hello, World!";

	        // Convert the String to StringBuffer
	        StringBuffer stringBuffer = new StringBuffer(originalString);

	        // Convert the String to StringBuilder
	        StringBuilder stringBuilder = new StringBuilder(originalString);

	        // Display the original String
	        System.out.println("Original String: " + originalString);

	        // Display the String converted to StringBuffer
	        System.out.println("String to StringBuffer: " + stringBuffer);

	        // Display the String converted to StringBuilder
	        System.out.println("String to StringBuilder: " + stringBuilder);
	    }
	}