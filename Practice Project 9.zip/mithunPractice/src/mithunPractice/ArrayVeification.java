package mithunPractice;

public class ArrayVeification {
	 public static void main(String[] args) {
	        // Declare and initialize an array of integers
	        int[] numbers = { 1, 2, 3, 4, 5 };

	        // Access and print elements of the array
	        System.out.println("Elements of the array:");
	        for (int i = 0; i < numbers.length; i++) {
	            System.out.println("Element at index " + i + ": " + numbers[i]);
	        }

	        // Update an element at a specific index
	        numbers[2] = 10;

	        // Access and print the updated element
	        System.out.println("\nUpdated element at index 2: " + numbers[2]);

	        // Find the length of the array
	        int arrayLength = numbers.length;
	        System.out.println("\nLength of the array: " + arrayLength);

	        // Declare and initialize an array of strings
	        String[] fruits = { "Apple", "Banana", "Orange", "Grapes" };

	        // Access and print elements of the string array
	        System.out.println("\nFruits in the array:");
	        for (int i = 0; i < fruits.length; i++) {
	            System.out.println("Fruit at index " + i + ": " + fruits[i]);
	        }
	    }
	}